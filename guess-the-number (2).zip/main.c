/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
   /* We will write a program that generates a random number and asks the player to guess
it. If the player’s guess is higher than the actual number, the program displays “Lower
number please”. Similarly, if the user’s guess is too low, the program prints “Higher
number please”.
When the user guesses the correct number, the program displays the number of
guesses the player used to arrive at the number.
Hint: Use loop & use a random number generator.*/


    int n = rand() % 40;//int randomNumber = rand() % 100;  // gives 0 to 99
    
    printf("Hello cuties!!\n");
    printf("we have a number let's see if you can guess it.\n");
    int i;
    printf("guess the number:\n");
    scanf("%d",&i);
    int k;
    for(int k =1;i!=n;k++){
        if(i<n){
            printf("the number is too low!!\t try again\n");
            scanf("%d",&i);
        }
        else if(i>n){
             printf("the number is too high!!\t try again\n");
             scanf("%d",&i);
             
        }
        printf(" you  have taken %d chance to guess.\n",k+1);
        }
        if(i==n){
        printf("hooray!! you have guessed the number corret!!!\n");
            
            
        }
        
        
        return 0;
    }
    



// factorial program through recursion

#include <stdio.h>
int factorial (int);
int factorial (int n){
    if(n==0 || n==1){
        return 1;//base condition
    }
    return factorial (n-1)*n;
}
int main()
{
    int a;
    printf("enter the number to get it's factorial:");
    scanf("%d",&a);
    printf("the factorial of %d is %d.\n",a,factorial (a));

    return 0;
}